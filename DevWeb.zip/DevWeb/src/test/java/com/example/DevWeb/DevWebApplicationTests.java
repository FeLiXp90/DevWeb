package com.example.DevWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
